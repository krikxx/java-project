
interface A {
    void methodA();
}
interface B {
    void methodB();
}

class C implements A, B {

    public void methodA() {
        System.out.println("Implementing methodA from interface A");
    }

    
    public void methodB() {
        System.out.println("Implementing methodB from interface B");
    }
}

public class Main {
    public static void main(String[] args) {
        C c = new C();
        c.methodA();
        c.methodB();
    }
}
