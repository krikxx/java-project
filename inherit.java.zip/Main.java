interface Printable{
    void print();
    }
    interface Showable{
        void show();
        class A7 implemnts Printable,Showable
    }
    public void print()
    {
    System.out.println("Hey");
    }
    public void show()
    { 
        System.out.println("There");
    }
    public static void main(String args[])
    A7 obj=new A7();
    obj.print();
    obj.show();
    }