interface Bank{
    void calculateInterest();
}
    class SBI implements Bank{
    double d,amt,interest;
    float r;
    void calculate(){
        r=0.5;
        amt=800;
        interest=amt*r;
        System.out.println("interest="+interest);
    }
    
}